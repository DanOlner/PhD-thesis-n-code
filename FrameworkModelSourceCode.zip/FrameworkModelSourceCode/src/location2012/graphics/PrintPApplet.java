/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package location2012.graphics;

/**
 *
 * @author geodo
 */
public interface PrintPApplet {
    
    public void printScreen();
    
}
