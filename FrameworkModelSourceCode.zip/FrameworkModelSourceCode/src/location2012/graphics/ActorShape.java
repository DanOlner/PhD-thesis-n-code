/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package location2012.graphics;

import processing.core.PApplet;
import processing.core.PGraphics;

/**
 * ActorShape: an object actors can use to have a drawable shape. So that different graphics windows can use it.
 * 
 * @author Dan
 */
public class ActorShape implements Drawable {

    @Override
    public void draw3D(PApplet p) {
    }

    @Override
    public void draw2D(PGraphics p) {
    }
    
    
       
    
    
}
