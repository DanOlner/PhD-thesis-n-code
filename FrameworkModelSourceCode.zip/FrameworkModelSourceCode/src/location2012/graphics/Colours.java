/*
 * Static methods for supplying a list of consistent colours up to a particular number
 */

package location2012.graphics;

import java.awt.Color;
import java.util.ArrayList;

/**
 *
 * @author Dan
 */
public class Colours {

    static Color c;

    static ArrayList<Color> colours = new ArrayList<Color>();

    //public static Color nextColor(float r, float g, float b, float a) {



    //}

}
