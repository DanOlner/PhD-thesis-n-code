/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package location2012.geog;

/**
 * Used by Torus to search in a radius from points who want to know what's around
 *
 * @author User
 */
public class RadiusSearcher {



}
