/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package location2012.utils;

/**
 * Provides some static methods for working with Reflections
 * @author geodo
 */
public class ReflectionsUtils {
    
    
    
}
