Core model visualisation: 

Press 'a' to toggle between long and short run equilibrium view. For the `tomahawk' long-run, each iteration will be drawn to screen, starting at T = 1.

When viewing the short-run equilibrium, up and down arrows change the value of T. The changed value is outputted to the java console.